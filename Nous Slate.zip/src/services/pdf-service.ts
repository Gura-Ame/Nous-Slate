import type { Deck } from "@/types/schema";
import { CardService } from "./card-service";

export const PdfService = {
	generatePrintView: async (decks: Deck[]) => {
		// 1. 抓取所有選取題庫的卡片資料
		const deckData = await Promise.all(
			decks.map(async (deck) => {
				const cards = await CardService.getCardsByDeck(deck.id);
				return { deck, cards };
			}),
		);

		// 2. 開啟新視窗
		const printWindow = window.open("", "_blank");
		if (!printWindow) {
			alert("請允許彈出式視窗以進行列印");
			return;
		}

		// 3. 建構 HTML
		const htmlContent = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>Nous Slate - 題庫匯出</title>
          <style>
            @import url('https://fonts.googleapis.com/css2?family=Noto+Sans+TC:wght@400;700&family=Noto+Serif+TC:wght@400;700&display=swap');
            body { font-family: 'Noto Sans TC', sans-serif; padding: 40px; color: #333; }
            .deck-section { margin-bottom: 50px; page-break-after: always; }
            .deck-section:last-child { page-break-after: auto; }
            h1 { font-size: 24px; border-bottom: 2px solid #333; padding-bottom: 10px; margin-bottom: 20px; }
            .deck-meta { font-size: 14px; color: #666; margin-bottom: 30px; }
            
            .card-item { margin-bottom: 20px; padding: 15px; border: 1px solid #ddd; border-radius: 8px; break-inside: avoid; }
            .card-type { font-size: 12px; font-weight: bold; color: #666; text-transform: uppercase; margin-bottom: 5px; }
            .card-stem { font-size: 18px; font-weight: bold; margin-bottom: 10px; white-space: pre-wrap; }
            .card-answer { margin-top: 10px; padding-top: 10px; border-top: 1px dashed #eee; font-size: 14px; color: #059669; }
            
            /* 注音樣式 */
            .zhuyin-block { display: inline-flex; border: 1px solid #333; margin-right: 5px; border-radius: 4px; overflow: hidden; }
            .zhuyin-char { width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; font-size: 24px; font-family: 'Noto Serif TC', serif; border-right: 1px solid #333; }
            .zhuyin-bopo { width: 20px; display: flex; flex-direction: column; justify-content: center; align-items: center; font-size: 10px; font-family: 'Noto Serif TC', serif; }
          </style>
        </head>
        <body>
          ${deckData
						.map(
							({ deck, cards }) => `
            <div class="deck-section">
              <h1>${deck.title}</h1>
              <div class="deck-meta">
                <span>${deck.stats.cardCount} 張卡片</span> • 
                <span>${deck.description || "無描述"}</span>
              </div>
              
              <div class="cards-list">
                ${cards
									.map((card) => {
										// 根據不同題型渲染內容
										let contentHtml = "";

										// 1. 國字注音 / 聽寫
										if (card.type === "term" || card.type === "dictation") {
											const blocks = card.content.blocks || [];
											const renderBlocks = blocks
												.map(
													(b) => `
                                                <div class="zhuyin-block">
                                                    <div class="zhuyin-char">${b.char}</div>
                                                    <div class="zhuyin-bopo">
                                                        <span>${b.zhuyin.initial + b.zhuyin.medial + b.zhuyin.final}</span>
                                                        <span>${b.zhuyin.tone}</span>
                                                    </div>
                                                </div>`,
												)
												.join("");
											contentHtml = `<div>${renderBlocks}</div>`;

											// 2. 選擇題
										} else if (card.type === "choice") {
											contentHtml = `
                                              <div class="card-stem">${card.content.stem}</div>
                                              <ul style="list-style: none; padding: 0;">
                                                ${(card.content.options || [])
																									.map(
																										(opt) =>
																											`<li style="padding: 4px 0;">⭕ ${opt}</li>`,
																									)
																									.join("")}
                                                <li style="padding: 4px 0; font-weight: bold;">✅ ${card.content.answer}</li>
                                              </ul>
                                            `;

											// 3. 其他
										} else {
											contentHtml = `<div class="card-stem">${card.content.stem}</div>`;
										}

										return `
                    <div class="card-item">
                      <div class="card-type">${card.type}</div>
                      ${contentHtml}
                      <div class="card-answer">
                        <strong>解析：</strong> ${card.content.meaning || "無"}
                      </div>
                    </div>
                  `;
									})
									.join("")}
              </div>
            </div>
          `,
						)
						.join("")}
          
          <script>
            window.onload = () => {
              window.print();
            }
          </script>
        </body>
      </html>
    `;

		printWindow.document.write(htmlContent);
		printWindow.document.close();
	},
};
